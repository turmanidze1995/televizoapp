package play.ott.nativeapp.account

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class TeleviziaSiteTest {
    @Test fun `plain hex code is accepted and normalised`() {
        assertEquals("A1B2C3D4E5F6", TeleviziaSite.codeFrom(" a1b2-c3d4 e5f6 "))
    }

    @Test fun `cabinet QR deep link yields its code`() {
        assertEquals("A1B2C3D4E5F6", TeleviziaSite.codeFrom("televizia://pair?code=A1B2C3D4E5F6"))
    }

    @Test fun `pair page url yields its code`() {
        assertEquals("A1B2C3D4E5F6", TeleviziaSite.codeFrom("https://televizia.store/public/pair.php?code=A1B2C3D4E5F6&auto=1"))
    }

    @Test fun `non hex or wrong length is rejected`() {
        assertNull(TeleviziaSite.codeFrom("hello world"))
        assertNull(TeleviziaSite.codeFrom("A1B2"))
        assertNull(TeleviziaSite.codeFrom("ZZZZZZZZZZZZ"))
    }

    @Test fun `pair page is https`() {
        assertEquals("https://televizia.store/public/pair.php?code=ABC", TeleviziaSite.pairPage("ABC"))
    }
}
