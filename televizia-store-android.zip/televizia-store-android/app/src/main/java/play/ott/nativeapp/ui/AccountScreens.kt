package play.ott.nativeapp.ui

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import play.ott.nativeapp.R
import play.ott.nativeapp.account.QrCode

@Composable
internal fun accountErrorText(error: AccountError): String = stringResource(when (error) {
    AccountError.BAD_CREDENTIALS -> R.string.account_error_bad_credentials
    AccountError.NO_PACKAGE -> R.string.account_error_no_package
    AccountError.NETWORK -> R.string.account_error_network
    AccountError.CODE_INVALID -> R.string.account_error_code_invalid
    AccountError.CODE_EXPIRED -> R.string.account_error_code_expired
    AccountError.SERVER -> R.string.account_error_server
    AccountError.MISSING_FIELDS -> R.string.account_error_missing
    AccountError.SCANNER_UNAVAILABLE -> R.string.account_error_scanner
})

/** აპი შესვლამდე: საწყისი ეკრანი, შემდეგ ლოგინი. ბიბლიოთეკა მხოლოდ შესვლის შემდეგ ჩანს. */
@Composable
fun AccountGate(state: AppUiState, onAction: (AppAction) -> Unit) {
    OttTheme {
        Surface(Modifier.fillMaxSize().safeDrawingPadding(), color = MaterialTheme.colorScheme.background) {
            if (!state.account.loaded || (state.account.signedIn)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Image(painterResource(R.drawable.logo_tv), null, Modifier.size(88.dp))
                        CircularProgressIndicator()
                    }
                }
            } else LoginScreen(state.account, onAction)
        }
    }
}

@Composable
private fun LoginScreen(account: AccountUi, onAction: (AppAction) -> Unit) {
    val configuration = LocalConfiguration.current
    val isTv = configuration.uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var codeDialog by rememberSaveable { mutableStateOf(false) }
    // ტელევიზორზე კოდი/QR თავისით იქმნება და მოწყობილობა ელოდება დადასტურებას ტელეფონიდან.
    if (isTv) {
        LaunchedEffect(Unit) { onAction(AppAction.StartPairing) }
        DisposableEffect(Unit) { onDispose { onAction(AppAction.StopPairing) } }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 720.dp
        val form: @Composable (Modifier) -> Unit = { modifier ->
            Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Image(painterResource(R.drawable.logo_tv), null, Modifier.size(56.dp))
                    Column {
                        Text("TELEVIZIA.STORE", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text(stringResource(R.string.account_brand_tagline), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(stringResource(R.string.account_login_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.account_login_subtitle), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = email, onValueChange = { email = it; if (account.error != null) onAction(AppAction.DismissAccountError) },
                    label = { Text(stringResource(R.string.account_email)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth().testTag("login-email"),
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it; if (account.error != null) onAction(AppAction.DismissAccountError) },
                    label = { Text(stringResource(R.string.account_password)) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth().testTag("login-password"),
                )
                account.error?.let { Text(accountErrorText(it), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
                ActionButton(
                    stringResource(if (account.busy) R.string.account_signing_in else R.string.account_sign_in),
                    { onAction(AppAction.Login(email, password)) },
                    Modifier.fillMaxWidth().testTag("login-submit"), selected = true, enabled = !account.busy,
                )
                if (!isTv) {
                    ActionButton(stringResource(R.string.account_scan), { onAction(AppAction.ScanQr) }, Modifier.fillMaxWidth(), enabled = !account.busy)
                    ActionButton(stringResource(R.string.account_enter_code), { codeDialog = true }, Modifier.fillMaxWidth(), enabled = !account.busy, compact = true)
                }
                if (!isTv) {
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        ActionButton(stringResource(R.string.account_register), { onAction(AppAction.OpenSite("register.php")) }, Modifier.weight(1f), compact = true)
                        ActionButton(stringResource(R.string.library_privacy_policy), { onAction(AppAction.OpenSite("terms.php")) }, Modifier.weight(1f), compact = true)
                    }
                }
            }
        }
        if (wide) {
            Row(Modifier.fillMaxSize().padding(if (isTv) 48.dp else 24.dp), horizontalArrangement = Arrangement.spacedBy(48.dp), verticalAlignment = Alignment.CenterVertically) {
                form(Modifier.weight(1f).verticalScroll(rememberScrollState()))
                if (isTv) PairPanel(account, Modifier.weight(1f))
            }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                form(Modifier.widthIn(max = 520.dp).fillMaxWidth())
            }
        }
    }
    if (codeDialog) {
        var code by rememberSaveable { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { codeDialog = false },
            title = { Text(stringResource(R.string.account_code_title)) },
            text = {
                OutlinedTextField(value = code, onValueChange = { code = it.take(40) }, singleLine = true,
                    label = { Text(stringResource(R.string.account_code_hint)) }, modifier = Modifier.fillMaxWidth().testTag("pair-code-input"))
            },
            dismissButton = { TextButton(onClick = { codeDialog = false }) { Text(stringResource(R.string.account_cancel)) } },
            confirmButton = { TextButton(onClick = { codeDialog = false; onAction(AppAction.PairWithCode(code)) }) { Text(stringResource(R.string.account_code_submit)) } },
        )
    }
}

/** ტელევიზორზე: დიდი QR + კოდი. ტელეფონით სკანირება → საიტზე დადასტურება → ტელევიზორი შედის. */
@Composable
private fun PairPanel(account: AccountUi, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.account_qr_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val url = account.pairUrl
        if (url != null) QrCode(url, 260.dp, Modifier.testTag("pair-qr"))
        else Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        account.pairCode?.let {
            Text(stringResource(R.string.account_code_label, it.chunked(4).joinToString(" ")),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        Text(stringResource(R.string.account_qr_hint), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(stringResource(R.string.account_waiting), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** ანგარიში: ვინ არის შესული, აქტიური პაკეტი/ტესტი და ვადები, გამოსვლა. */
@Composable
internal fun AccountDialog(account: AccountUi, onAction: (AppAction) -> Unit, onDismiss: () -> Unit) {
    var confirmLogout by remember { mutableStateOf(false) }
    AlertDialog(
        modifier = Modifier.tvRemoteInput(),
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.account_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (account.name.isNotBlank()) Text(stringResource(R.string.account_signed_in_as, account.name), style = MaterialTheme.typography.titleMedium)
                if (account.packages.isEmpty() && account.trialExpiresAt == null) Text(stringResource(R.string.account_plan_none))
                account.packages.forEach { Text(stringResource(R.string.account_plan_package, it.name, it.expiresAt)) }
                account.trialExpiresAt?.let { Text(stringResource(R.string.account_plan_trial, it)) }
                if (account.expired) Text(stringResource(R.string.account_expired), color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                ActionButton(stringResource(R.string.account_refresh), { onAction(AppAction.RefreshAccount); onDismiss() }, Modifier.fillMaxWidth())
                val isTv = LocalConfiguration.current.uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION
                if (!isTv) ActionButton(stringResource(R.string.account_manage), { onAction(AppAction.OpenSite("package.php")) }, Modifier.fillMaxWidth())
                ActionButton(stringResource(R.string.account_logout), { confirmLogout = true }, Modifier.fillMaxWidth())
            }
        },
        confirmButton = { ActionButton(stringResource(R.string.library_done), onDismiss, selected = true) },
    )
    if (confirmLogout) {
        AlertDialog(
            modifier = Modifier.tvRemoteInput(),
            onDismissRequest = { confirmLogout = false },
            title = { Text(stringResource(R.string.account_logout_title)) },
            text = { Text(stringResource(R.string.account_logout_body)) },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text(stringResource(R.string.account_cancel)) } },
            confirmButton = { ActionButton(stringResource(R.string.account_logout), { confirmLogout = false; onDismiss(); onAction(AppAction.Logout) }) },
        )
    }
}
