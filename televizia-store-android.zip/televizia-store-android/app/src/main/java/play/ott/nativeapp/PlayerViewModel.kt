package play.ott.nativeapp

import play.ott.nativeapp.i18n.AppLanguages
import android.app.Application
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import play.ott.nativeapp.core.*
import play.ott.nativeapp.data.NativeRepository
import play.ott.nativeapp.playback.PlaybackItems
import play.ott.nativeapp.ui.AppAction
import play.ott.nativeapp.ui.AppUiState
import play.ott.nativeapp.ui.AccountError
import play.ott.nativeapp.ui.AccountPackageUi
import play.ott.nativeapp.ui.AccountUi
import play.ott.nativeapp.account.AccountStore
import play.ott.nativeapp.account.ApiResult
import play.ott.nativeapp.account.SiteSession
import play.ott.nativeapp.account.StoredAccount
import play.ott.nativeapp.account.TeleviziaApi
import play.ott.nativeapp.account.TeleviziaSite
import play.ott.nativeapp.account.toStored

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class PlayerViewModel internal constructor(application: Application, private val repository: NativeRepository) : AndroidViewModel(application) {
    constructor(application: Application) : this(application, (application as OttplayApplication).repository)
    private fun message(id: Int, vararg args: Any) = AppLanguages.localizedContext(getApplication()).getString(id, *args)
    private var loadingResource = R.string.message_loading_library
    private var errorText: (() -> String)? = null
    private var noticeText: (() -> String)? = null
    private val mutableState = MutableStateFlow(AppUiState(isBusy = true, loadingMessage = message(loadingResource)))
    val state: StateFlow<AppUiState> = mutableState.asStateFlow()
    private fun updateState(forceLocalization: Boolean = false, transform: (AppUiState) -> AppUiState) {
        mutableState.update { old ->
            val next = transform(old)
            next.copy(sources = if (forceLocalization || next.sources !== old.sources) next.sources.map(repository::displaySource) else old.sources,
                entries = if (forceLocalization || next.entries !== old.entries) next.entries.map(repository::displayEntry) else old.entries,
                episodes = if (forceLocalization || next.episodes !== old.episodes) next.episodes.map(repository::displayEntry) else old.episodes,
                playingEntry = if (forceLocalization || next.playingEntry !== old.playingEntry) next.playingEntry?.let(repository::displayEntry) else old.playingEntry,
                epgEntry = if (forceLocalization || next.epgEntry !== old.epgEntry) next.epgEntry?.let(repository::displayEntry) else old.epgEntry,
                seriesEntry = if (forceLocalization || next.seriesEntry !== old.seriesEntry) next.seriesEntry?.let(repository::displayEntry) else old.seriesEntry)
        }
    }

    /** Activity recreation can retain this VM. Refresh labels without networking or touching playback. */
    fun onLocaleChanged() {
        updateState(forceLocalization = true) { it.copy(loadingMessage = message(loadingResource),
            error = errorText?.invoke(), notice = noticeText?.invoke()) }
        viewModelScope.launch {
            try {
                val sources = repository.sources()
                updateState { it.copy(sources = sources) }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { /* Keep the already displayed catalogue if storage is temporarily unavailable. */ }
        }
    }

    private fun setErrorText(text: () -> String) {
        errorText = text
        updateState { it.copy(error = text()) }
    }

    private fun setNoticeText(text: () -> String) {
        noticeText = text
        updateState { it.copy(notice = text()) }
    }

    private fun rememberCatalogNotes(catalog: Catalog) {
        if (catalog.notes.isNotEmpty() || catalog.messages.isNotEmpty()) noticeText = {
            repository.catalogNotes(catalog).joinToString("\n")
        }
    }

    // TELEVIZIA.STORE ანგარიში: დაგვიანებით იქმნება, რომ ტესტებსა და ცივ გაშვებაზე Keystore-ს ადრე არ შევეხოთ.
    internal var accountApi: TeleviziaApi by lazyVar { TeleviziaApi() }
    internal var accountStore: AccountStore by lazyVar { AccountStore(getApplication()) }
    private var pairJob: Job? = null

    private var controller: MediaController? = null
    private var loadJob: Job? = null
    private var detailJob: Job? = null
    private var playJob: Job? = null
    private var recoveryJob: Job? = null
    private var localAutoplayJob: Job? = null
    private var localAutoplaySource: String? = null
    private var localAutoplayGeneration = 0L
    private var pendingLocalAutoplaySource: String? = null
    private var playGeneration = 0L
    private var resolvingSourceId: String? = null
    private var loadGeneration = 0L
    private var pending: PendingPlay? = null
    private data class PendingPlay(val entry: MediaEntry, val stream: PlaybackStream, val positionMs: Long, val local: Boolean = false, val shuffle: Boolean = false)
    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            setErrorText { play.ott.nativeapp.playback.PlaybackErrors.message(getApplication(), error) }
        }
        override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
            controller?.let { restorePlaybackEntry(it, item) }
        }
    }
    init {
        viewModelScope.launch { restoreAccount() }
        viewModelScope.launch {
            repository.preferences.data.collect { preferences ->
                updateState { it.copy(favoriteIds = preferences.favorites, backgroundPlayback = preferences.backgroundPlayback) }
            }
        }
        viewModelScope.launch {
            try {
                val sources = repository.sources()
                val selected = repository.preferences.data.first().selectedSourceId
                    ?.takeIf { id -> sources.any { it.id == id } } ?: sources.firstOrNull()?.id
                updateState { it.copy(sources = sources, selectedSourceId = selected, isBusy = false) }
                if (selected != null) load(selected, refresh = false)
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                updateState { it.copy(isBusy = false) }; setErrorText { message(R.string.message_saved_sources_unreadable) }
            }
        }
    }

    fun attachController(value: MediaController) {
        controller?.removeListener(listener)
        controller = value
        value.addListener(listener)
        pending?.let {
            pending = null
            try { begin(it) } catch (error: Exception) { showError(error) }
        }
        restorePlaybackEntry(value, value.currentMediaItem)
    }

    fun detachController(value: MediaController?) {
        if (controller === value) { recoveryJob?.cancel(); value?.removeListener(listener); controller = null }
    }

    /** The player may belong to a different source than the catalogue currently being browsed. */
    private fun restorePlaybackEntry(value: MediaController, item: MediaItem?) {
        recoveryJob?.cancel()
        if (item == null) {
            updateState { it.copy(playingEntry = null) }
            return
        }
        if (state.value.playingEntry?.id == item.mediaId) return
        val generation = playGeneration
        recoveryJob = viewModelScope.launch {
            try {
                val sources = repository.sources()
                val sourceIds = sources.mapTo(hashSetOf()) { it.id }
                var entry = state.value.entries.firstOrNull { it.id == item.mediaId && it.sourceId in sourceIds }
                if (entry == null) {
                    // Episodes and archive items are not in the top-level cached catalogue. Keep
                    // their descriptor in private request metadata, alongside the existing URL.
                    entry = item.requestMetadata.extras?.getString(EXTRA_ENTRY)?.let { encoded ->
                        runCatching { entryJson.decodeFromString<MediaEntry>(encoded) }.getOrNull()
                    }?.takeIf { it.id == item.mediaId && it.sourceId in sourceIds }
                }
                if (entry == null) {
                    for (source in sources) {
                        val cached = try { repository.cached(source.id).entries }
                        catch (e: CancellationException) { throw e }
                        catch (_: Exception) { continue } // An unrelated broken cache cannot hide an active player.
                        ensureActive()
                        entry = cached.firstOrNull { it.id == item.mediaId && it.sourceId == source.id }
                        if (entry != null) break
                    }
                }
                val recoveredSourceId = entry?.sourceId
                if (recoveredSourceId != null && repository.sources().none { it.id == recoveredSourceId }) entry = null
                ensureActive()
                if (controller !== value || value.currentMediaItem?.mediaId != item.mediaId || generation != playGeneration) return@launch
                updateState { it.copy(playingEntry = entry) }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                if (controller === value && value.currentMediaItem?.mediaId == item.mediaId) {
                    setNoticeText { message(R.string.message_playback_description_unavailable) }
                }
            }
        }
    }

    fun onPlaybackSessionError() { setErrorText { message(R.string.message_channel_switch_failed) } }
    fun onLocalPickerUnavailable() { setErrorText { message(R.string.local_picker_unavailable) } }

    fun onControllerFailure() { updateState { it.copy(isBusy = false) }; setErrorText { message(R.string.message_controller_unavailable) } }

    fun dispatch(action: AppAction) {
        when (action) {
            is AppAction.SelectSource -> load(action.sourceId, false)
            is AppAction.SaveSource -> operation {
                retirePendingSource(action.source.id)
                loadJob?.cancelAndJoin()
                repository.save(action.source)
                val sources = repository.sources()
                updateState { it.copy(sources = sources) }
                load(action.source.id, true)
            }
            is AppAction.DeleteSource -> operation {
                retirePendingSource(action.sourceId)
                if (state.value.playingEntry?.sourceId == action.sourceId) stop()
                loadJob?.cancel()
                repository.remove(action.sourceId)
                val sources = repository.sources()
                val id = state.value.selectedSourceId?.takeUnless { it == action.sourceId } ?: sources.firstOrNull()?.id
                updateState { it.copy(sources = sources, selectedSourceId = id, entries = emptyList(), isBusy = false) }
                if (id != null) load(id, false)
            }
            AppAction.Refresh -> state.value.selectedSourceId?.let { load(it, true) }
            AppAction.CancelLocalScan -> state.value.selectedSourceId?.let {
                cancelLocalAutoplay(it)
                repository.localVideos.cancel(it)
            }
            AppAction.PlayLocalShuffle -> if (state.value.sources.any { it.id == state.value.selectedSourceId && it.kind == SourceKind.LOCAL }) {
                state.value.entries.randomOrNull()?.let { play(it, shuffle = true) }
            }
            is AppAction.ToggleFavorite -> operation {
                repository.preferences.update {
                    it.copy(favorites = play.ott.core.DurableSelections.toggle(it.favorites, action.entry.id))
                }
            }
            is AppAction.Play -> play(action.entry)
            is AppAction.OpenEpg -> {
                detailJob?.cancel()
                updateState { it.copy(epgEntry = action.entry, programmes = emptyList()) }
                detailJob = operation {
                    val programmes = repository.programmes(action.entry)
                    updateState { if (it.epgEntry?.id == action.entry.id) it.copy(programmes = programmes) else it }
                }
            }
            is AppAction.PlayProgramme -> {
                val stream = CatchupResolver.resolve(action.entry, action.programme)
                if (stream == null) setErrorText { message(R.string.message_archive_unavailable) }
                else play(action.entry.copy(id = action.entry.id + ":archive:" + action.programme.startMillis,
                    name = action.programme.title, nameMessage = null, kind = MediaKind.MOVIE), stream)
            }
            is AppAction.OpenSeries -> {
                detailJob?.cancel()
                updateState { it.copy(seriesEntry = action.entry, episodes = emptyList()) }
                detailJob = operation {
                    val source = repository.sources().first { it.id == action.entry.sourceId }
                    val episodes = repository.providers.loadEpisodes(source, action.entry)
                    updateState { if (it.seriesEntry?.id == action.entry.id) it.copy(episodes = episodes) else it }
                }
            }
            AppAction.CloseEpg -> { detailJob?.cancel(); updateState { it.copy(epgEntry = null, programmes = emptyList()) } }
            AppAction.CloseSeries -> { detailJob?.cancel(); updateState { it.copy(seriesEntry = null, episodes = emptyList()) } }
            AppAction.DismissError -> { errorText = null; updateState { it.copy(error = null) } }
            AppAction.DismissNotice -> { noticeText = null; updateState { it.copy(notice = null) } }
            AppAction.StopPlayback -> stop()
            is AppAction.SetBackgroundPlayback -> operation { repository.preferences.update { it.copy(backgroundPlayback = action.enabled) } }
            is AppAction.SetTrackPreference -> operation {
                action.preference.validate()
                repository.preferences.update {
                    if (action.audio) it.copy(audioTrack = action.preference)
                    else it.copy(subtitleTrack = action.preference)
                }
            }
            AppAction.AddDemo -> operation {
                val source = NativeRepository.demoSource()
                repository.save(source)
                val sources = repository.sources()
                updateState { it.copy(sources = sources) }
                load(source.id, true)
            }
            is AppAction.Login -> login(action.email, action.password)
            AppAction.StartPairing -> startPairing()
            AppAction.StopPairing -> stopPairing()
            is AppAction.PairWithCode -> pairWithCode(action.code)
            AppAction.Logout -> logout()
            AppAction.RefreshAccount -> viewModelScope.launch { refreshAccount() }
            AppAction.DismissAccountError -> setAccount { it.copy(error = null) }
            AppAction.ScanQr, is AppAction.OpenSite -> Unit // ტელეფონის სკანერი/ბრაუზერი Activity-შია
            AppAction.ImportPlaylist, AppAction.ImportLocalFolder, AppAction.ImportLocalFiles,
            AppAction.ImportSettings, AppAction.ExportSettings -> Unit // System document launchers in Activity.
        }
    }


    // ───────────────────────── TELEVIZIA.STORE ანგარიში ─────────────────────────

    private fun <T> lazyVar(init: () -> T) = object : kotlin.properties.ReadWriteProperty<Any?, T> {
        private var value: Any? = UNSET
        @Suppress("UNCHECKED_CAST")
        override fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>): T {
            if (value === UNSET) value = init()
            return value as T
        }
        override fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: T) { this.value = value }
    }

    private fun setAccount(transform: (AccountUi) -> AccountUi) = updateState { it.copy(account = transform(it.account)) }

    private fun StoredAccount.toUi(busy: Boolean = false) = AccountUi(
        loaded = true, signedIn = true, name = name, kind = kind,
        packages = packages.map { AccountPackageUi(it.name, it.expiresAt) },
        trialExpiresAt = trial?.expiresAt, expired = expired, busy = busy,
    )

    private fun failure(kind: ApiResult.Kind) = when (kind) {
        ApiResult.Kind.BAD_CREDENTIALS -> AccountError.BAD_CREDENTIALS
        ApiResult.Kind.NO_PACKAGE -> AccountError.NO_PACKAGE
        ApiResult.Kind.NETWORK -> AccountError.NETWORK
        ApiResult.Kind.INVALID_CODE -> AccountError.CODE_INVALID
        ApiResult.Kind.EXPIRED -> AccountError.CODE_EXPIRED
        else -> AccountError.SERVER
    }

    fun onScannerUnavailable() = setAccount { it.copy(error = AccountError.SCANNER_UNAVAILABLE) }

    /** აპის გახსნა: შენახული ტოკენით ვაგრძელებთ, ახალი მდგომარეობა კი ფონზე მოდის (ოფლაინშიც მუშაობს ქეშით). */
    private suspend fun restoreAccount() {
        val stored = try { withContext(Dispatchers.IO) { accountStore.read() } }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { null }
        if (stored == null) { setAccount { it.copy(loaded = true) }; return }
        setAccount { stored.toUi() }
        refreshAccount()
    }

    private suspend fun refreshAccount() {
        val stored = (try { withContext(Dispatchers.IO) { accountStore.read() } }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { null }) ?: return
        when (val result = accountApi.refresh(stored.token)) {
            is ApiResult.Success -> applySession(result.session)
            is ApiResult.Failure -> when (result.kind) {
                // ტოკენი აღარ არსებობს (პაროლი შეიცვალა / ანგარიში წაიშალა): ხელახალი შესვლა
                ApiResult.Kind.INVALID_TOKEN -> signOut()
                // პაკეტიცა და ტესტიც დასრულდა: საიტი playlist-ში თვითონ აჩვენებს ვადის გასვლის შეტყობინებას
                ApiResult.Kind.NO_PACKAGE -> {
                    val expired = stored.copy(expired = true)
                    withContext(Dispatchers.IO) { runCatching { accountStore.write(expired) } }
                    setAccount { expired.toUi() }
                }
                else -> Unit // ქსელი არ არის — ძველი მონაცემებით ვაგრძელებთ
            }
            ApiResult.Pending -> Unit
        }
    }

    /** შესვლა/განახლება: ანგარიში ინახება, playlist წყარო იცვლება და არხები ავტომატურად იტვირთება. */
    private suspend fun applySession(session: SiteSession) {
        val stored = session.toStored()
        withContext(Dispatchers.IO) { accountStore.write(stored) }
        val source = SourceConfig(id = TeleviziaSite.SOURCE_ID, name = TeleviziaSite.SOURCE_NAME, kind = SourceKind.M3U,
            url = session.playlistUrl, nameIsUserDefined = true)
        val unchanged = repository.sources().firstOrNull { it.id == source.id } == source
        setAccount { stored.toUi() }
        if (unchanged && state.value.selectedSourceId == source.id) return
        retirePendingSource(source.id)
        loadJob?.cancelAndJoin()
        repository.save(source)
        val sources = repository.sources()
        updateState { it.copy(sources = sources) }
        load(source.id, refresh = !unchanged)
    }

    private fun login(email: String, password: String) {
        if (state.value.account.busy) return
        if (email.isBlank() || password.isEmpty()) { setAccount { it.copy(error = AccountError.MISSING_FIELDS) }; return }
        setAccount { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            try {
                when (val result = accountApi.login(email, password)) {
                    is ApiResult.Success -> { stopPairing(); applySession(result.session) }
                    is ApiResult.Failure -> setAccount { it.copy(busy = false, error = failure(result.kind)) }
                    ApiResult.Pending -> setAccount { it.copy(busy = false, error = AccountError.SERVER) }
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { setAccount { it.copy(busy = false, error = AccountError.SERVER) } }
        }
    }

    /** ტელეფონი: კაბინეტის QR ან ხელით შეყვანილი 12-სიმბოლოიანი კოდი (ერთჯერადი, 3 წუთი). */
    private fun pairWithCode(text: String) {
        val code = TeleviziaSite.codeFrom(text)
        if (code == null) { setAccount { it.copy(error = AccountError.CODE_INVALID) }; return }
        setAccount { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            try {
                when (val result = accountApi.pairCheck(code)) {
                    is ApiResult.Success -> { stopPairing(); applySession(result.session) }
                    is ApiResult.Failure -> setAccount { it.copy(busy = false, error = failure(result.kind)) }
                    ApiResult.Pending -> setAccount { it.copy(busy = false, error = AccountError.CODE_INVALID) }
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { setAccount { it.copy(busy = false, error = AccountError.SERVER) } }
        }
    }

    /**
     * ტელევიზორი: კოდი + QR. ტელეფონით დასკანერებისა და საიტზე დადასტურების შემდეგ
     * pair_check ტოკენს აბრუნებს და ტელევიზორი თვითონ შედის. ვადაგასულ კოდს ახალი ცვლის.
     */
    private fun startPairing() {
        if (pairJob?.isActive == true) return
        pairJob = viewModelScope.launch {
            while (isActive) {
                val start = accountApi.pairStart()
                if (start == null) {
                    setAccount { it.copy(pairCode = null, pairUrl = null, error = AccountError.NETWORK) }
                    delay(5_000); continue
                }
                setAccount { it.copy(pairCode = start.code, pairUrl = TeleviziaSite.pairPage(start.code),
                    error = if (it.error == AccountError.NETWORK) null else it.error) }
                val deadline = SystemClock.elapsedRealtime() + start.expiresIn * 1000L - 5_000
                while (isActive && SystemClock.elapsedRealtime() < deadline) {
                    delay(3_000)
                    when (val result = try { accountApi.pairCheck(start.code) } catch (e: CancellationException) { throw e } catch (_: Exception) { null }) {
                        is ApiResult.Success -> {
                            try { applySession(result.session) } catch (e: CancellationException) { throw e } catch (e: Exception) { showError(e) }
                            return@launch
                        }
                        is ApiResult.Failure -> when (result.kind) {
                            ApiResult.Kind.NO_PACKAGE -> { setAccount { it.copy(error = AccountError.NO_PACKAGE) }; break }
                            ApiResult.Kind.EXPIRED, ApiResult.Kind.INVALID_CODE -> break
                            else -> Unit
                        }
                        else -> Unit
                    }
                }
            }
        }
    }

    private fun stopPairing() {
        pairJob?.cancel(); pairJob = null
        setAccount { it.copy(pairCode = null, pairUrl = null) }
    }

    private fun logout() { operation { signOut() } }

    private suspend fun signOut() {
        pairJob?.cancel(); pairJob = null
        retirePendingSource(TeleviziaSite.SOURCE_ID)
        stop()
        loadJob?.cancelAndJoin()
        withContext(Dispatchers.IO) { runCatching { accountStore.clear() } }
        repository.remove(TeleviziaSite.SOURCE_ID)
        val sources = repository.sources()
        updateState { it.copy(sources = sources, selectedSourceId = null, entries = emptyList(), epgEntry = null,
            seriesEntry = null, isBusy = false, error = null, account = AccountUi(loaded = true)) }
    }

    private fun load(id: String, refresh: Boolean, autoPlay: Boolean = false) {
        cancelLocalAutoplay()
        val autoplayGeneration = localAutoplayGeneration
        val autoplayIntent = playGeneration
        if (autoPlay) localAutoplaySource = id
        loadingResource = R.string.message_loading_catalog
        errorText = null
        val previous = state.value.selectedSourceId
        if (previous != null && previous != id && state.value.playingEntry?.sourceId != previous) repository.localVideos.cancel(previous)
        loadJob?.cancel()
        val generation = ++loadGeneration
        detailJob?.cancel()
        updateState { it.copy(selectedSourceId = id, entries = emptyList(), epgEntry = null,
            seriesEntry = null, isBusy = true, localScanning = false, loadingMessage = message(loadingResource), error = null) }
        loadJob = viewModelScope.launch {
            try {
                repository.preferences.update { it.copy(selectedSourceId = id) }
                val source = repository.sources().first { it.id == id }
                if (source.kind == SourceKind.LOCAL) {
                    val snapshots = repository.localVideos.scan(source, refresh)
                    if (autoPlay) startLocalAutoplay(source, snapshots, generation, autoplayGeneration, autoplayIntent)
                    snapshots.first { snapshot ->
                        ensureActive()
                        if (generation != loadGeneration) return@first true
                        updateState { it.copy(entries = snapshot.entries, localScanning = snapshot.scanning,
                            isBusy = snapshot.scanning && snapshot.entries.isEmpty()) }
                        if (snapshot.failed) setNoticeText { message(R.string.local_scan_failed) }
                        !snapshot.scanning
                    }
                    return@launch
                }
                val cached = try { repository.cached(id) } catch (e: Exception) {
                    if (e is CancellationException || !refresh) throw e
                    Catalog(emptyList())
                }
                if (state.value.selectedSourceId != id) return@launch
                rememberCatalogNotes(cached)
                updateState { it.copy(entries = cached.entries, notice = noticeText?.invoke() ?: it.notice) }
                val catalog = if (refresh || cached.entries.isEmpty()) repository.refresh(source) else cached
                ensureActive()
                if (state.value.selectedSourceId != id) return@launch
                rememberCatalogNotes(catalog)
                updateState { it.copy(entries = catalog.entries, isBusy = false, notice = noticeText?.invoke() ?: it.notice) }
                if (refresh || cached.entries.isEmpty()) {
                    try {
                        repository.refreshEpg(source, catalog)
                    } catch (e: CancellationException) { throw e }
                    catch (_: Exception) {
                        val previous = noticeText
                        setNoticeText { listOfNotNull(previous?.invoke(), message(R.string.message_epg_unavailable)).distinct().joinToString("\n") }
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { showError(e) }
            finally { if (generation == loadGeneration && state.value.selectedSourceId == id) updateState { it.copy(isBusy = false) } }
        }
    }

    private fun cancelLocalAutoplay(sourceId: String? = null) {
        if (sourceId != null && localAutoplaySource != sourceId && pendingLocalAutoplaySource != sourceId) return
        ++localAutoplayGeneration
        localAutoplayJob?.cancel(); localAutoplayJob = null; localAutoplaySource = null
        if (pendingLocalAutoplaySource != null) {
            playJob?.cancel(); ++playGeneration
            val queued = pending?.entry
            pending = null; resolvingSourceId = null
            if (queued != null && state.value.playingEntry?.id == queued.id) updateState { it.copy(playingEntry = null) }
            pendingLocalAutoplaySource = null
        }
    }

    private fun startLocalAutoplay(source: SourceConfig,
        snapshots: StateFlow<play.ott.nativeapp.data.LocalVideoSnapshot>, load: Long,
        generation: Long, intent: Long) {
        if (generation != localAutoplayGeneration || intent != playGeneration || load != loadGeneration ||
            localAutoplaySource != source.id) return
        localAutoplayJob = viewModelScope.launch {
            try {
                val ready = play.ott.nativeapp.data.firstPlayableLocalVideo(snapshots) {
                    repository.localVideos.validate(source, it)
                }
                if (ready == null) {
                    if (generation == localAutoplayGeneration && !snapshots.value.cancelled)
                        setNoticeText { message(R.string.local_scan_failed) }
                    return@launch
                }
                val unchanged = repository.sources().firstOrNull { it.id == source.id } == source
                ensureActive()
                if (generation != localAutoplayGeneration || intent != playGeneration || load != loadGeneration ||
                    snapshots.value.cancelled || !unchanged) return@launch
                play(ready, PlaybackStream(ready.url, mimeType = ready.mimeType), autoStart = true, resolvedSource = source)
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (error: Exception) { if (generation == localAutoplayGeneration) showError(error) }
            finally { if (generation == localAutoplayGeneration) { localAutoplayJob = null; localAutoplaySource = null } }
        }
    }

    private fun play(entry: MediaEntry, resolved: PlaybackStream? = null, shuffle: Boolean = false, autoStart: Boolean = false,
        resolvedSource: SourceConfig? = null) {
        cancelLocalAutoplay()
        if (entry.playbackUnsupportedReason != null) {
            setErrorText { message(R.string.message_unsupported_playback) }
            return
        }
        if (entry.kind == MediaKind.SERIES) { dispatch(AppAction.OpenSeries(entry)); return }
        playJob?.cancel()
        pending = null
        resolvingSourceId = entry.sourceId
        val generation = ++playGeneration
        pendingLocalAutoplaySource = entry.sourceId.takeIf { autoStart }
        playJob = operation {
            val source = repository.sources().first { it.id == entry.sourceId }
            check(resolvedSource == null || source == resolvedSource) { "Source changed after local validation" }
            val stream = resolved ?: repository.stream(source, entry)
            val position = if (entry.kind == MediaKind.LIVE) 0L else repository.preferences.data.first().resumePositions[entry.id] ?: 0L
            ensureActive()
            if (generation != playGeneration) return@operation
            val unchanged = repository.sources().firstOrNull { it.id == source.id } == source
            ensureActive()
            if (generation != playGeneration) return@operation
            if (!unchanged) error("Source changed during playback request")
            val request = PendingPlay(entry, stream, position, source.kind == SourceKind.LOCAL, shuffle)
            if (controller == null) {
                pending = request
                updateState { it.copy(playingEntry = entry) }; setNoticeText { message(R.string.message_connecting_playback) }
            } else begin(request)
        }
    }

    private fun begin(request: PendingPlay) {
        val player = controller ?: return
        resolvingSourceId = null
        pendingLocalAutoplaySource = null
        val item = PlaybackItems.build(
            id = request.entry.id, title = repository.displayEntry(request.entry).name, url = request.stream.url,
            headers = request.stream.headers, artwork = request.entry.logo.takeIf { it.isNotBlank() },
            isLive = request.entry.kind == MediaKind.LIVE, startPositionMs = request.positionMs,
            drm = request.entry.drm, mimeType = request.entry.mimeType ?: request.stream.mimeType,
            unsupportedReason = request.entry.playbackUnsupportedReason,
        ).let { built ->
            val extras = Bundle(built.requestMetadata.extras ?: Bundle()).apply {
                putString(EXTRA_ENTRY, entryJson.encodeToString(request.entry))
                if (request.local) {
                    putString(play.ott.nativeapp.playback.LocalPlaybackQueue.EXTRA_SOURCE, request.entry.sourceId)
                    putBoolean(play.ott.nativeapp.playback.LocalPlaybackQueue.EXTRA_SHUFFLE, request.shuffle)
                }
            }
            built.buildUpon()
                .setRequestMetadata(built.requestMetadata.buildUpon().setExtras(extras).build())
                .build()
        }
        PlaybackItems.requireSupported(getApplication(), item)
        player.setMediaItem(item, PlaybackItems.startPositionMs(item))
        player.prepare()
        player.play()
        errorText = null; noticeText = null
        updateState { it.copy(playingEntry = request.entry, error = null, notice = null) }
    }

    private fun retirePendingSource(sourceId: String) {
        cancelLocalAutoplay(sourceId)
        if (resolvingSourceId == sourceId || pending?.entry?.sourceId == sourceId) {
            playJob?.cancel(); ++playGeneration; pending = null; resolvingSourceId = null
        }
    }

    private fun stop() {
        cancelLocalAutoplay()
        playJob?.cancel(); ++playGeneration; pending = null; resolvingSourceId = null
        controller?.stop(); controller?.clearMediaItems()
        updateState { it.copy(playingEntry = null) }
    }

    fun importPlaylist(uri: Uri, name: String) = operation {
        try {
            withContext(Dispatchers.IO) {
                play.ott.nativeapp.data.PersistedDocumentGrants.take(getApplication<Application>().contentResolver,
                    listOf(uri), message(R.string.local_grant_limit))
            }
        } catch (_: SecurityException) { /* A transient readable playlist keeps its existing import behavior. */ }
        val source = NativeRepository.fileSource(uri.toString(), name)
        repository.save(source)
        val sources = repository.sources()
        updateState { it.copy(sources = sources) }
        load(source.id, true)
    }

    fun importLocal(uris: List<Uri>, folder: Boolean): Job {
        val intent = playGeneration
        val autoplay = localAutoplayGeneration
        return operation {
            val source = repository.addLocal(uris, folder)
            val sources = repository.sources()
            updateState { it.copy(sources = sources) }
            load(source.id, true, autoPlay = intent == playGeneration && autoplay == localAutoplayGeneration)
        }
    }

    fun importSettings(uri: Uri) = operation {
        val text = withContext(Dispatchers.IO) {
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { play.ott.nativeapp.data.readBounded(it, 4 * 1024 * 1024).decodeToString() }
                ?: error(message(R.string.message_file_unavailable))
        }
        // Import may replace accounts. A detached controller must not later start a URL resolved
        // with the previous credentials; currently playing media remains owned by the service.
        playJob?.cancelAndJoin()
        ++playGeneration
        pending = null
        resolvingSourceId = null
        loadJob?.cancelAndJoin()
        val result = repository.importSettings(text)
        val sources = repository.sources()
        updateState { it.copy(sources = sources) }
        setNoticeText { listOf(message(R.string.message_imported_sources, result.count))
            .plus(repository.importNotes(result)).joinToString(". ") }
        val selected = repository.preferences.data.first().selectedSourceId
        (sources.firstOrNull { it.id == selected } ?: sources.firstOrNull())?.let { load(it.id, false) }
    }

    fun exportSettings(uri: Uri) = operation {
        val text = repository.exportSettings()
        withContext(Dispatchers.IO) {
            getApplication<Application>().contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(text) }
                ?: error(message(R.string.message_file_write_failed))
        }
        setNoticeText { message(R.string.message_export_complete) }
    }

    private fun operation(block: suspend CoroutineScope.() -> Unit): Job = viewModelScope.launch {
        try { block() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { showError(e) }
    }

    private fun showError(error: Exception) {
        // Network/library exception messages may contain provider URLs and credentials.
        val resource = when (error) {
            is play.ott.nativeapp.data.DocumentGrantLimitException -> R.string.local_grant_limit
            is java.net.UnknownHostException -> R.string.message_host_not_found
            is java.net.SocketTimeoutException -> R.string.message_network_timeout
            else -> R.string.message_operation_failed
        }
        updateState { it.copy(isBusy = false) }
        setErrorText { message(resource) }
    }

    private companion object {
        const val EXTRA_ENTRY = "play.ott.nativeapp.entry"
        val UNSET = Any()
        val entryJson = Json { ignoreUnknownKeys = true }
    }
}
