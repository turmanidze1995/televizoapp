package play.ott.nativeapp.account

import android.content.Context
import android.util.AtomicFile
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import play.ott.nativeapp.data.SourceVault
import java.io.File

/** შენახული შესვლა. პაროლი არასდროს ინახება — მხოლოდ საიტის ტოკენი (დაშიფრული, backup-ში არ ხვდება). */
@Serializable
data class StoredAccount(
    val token: String,
    val kind: String,
    val name: String = "",
    val playlistUrl: String,
    val packages: List<PackageInfo> = emptyList(),
    val trial: TrialInfo? = null,
    /** პაკეტი/ტესტი დასრულდა; playlist-ს საიტი თვითონ აჩვენებს "ვადა გაუვიდა" შეტყობინებით */
    val expired: Boolean = false,
) {
    override fun toString(): String = "StoredAccount(kind=$kind)"
}

fun SiteSession.toStored() = StoredAccount(token, kind, name, playlistUrl, packages, trial)

class AccountStore(context: Context) {
    private val vault = SourceVault(context)
    private val file = AtomicFile(File(context.noBackupFilesDir, "televizia-account.enc"))
    private val json = Json { ignoreUnknownKeys = true }

    @Synchronized fun read(): StoredAccount? {
        if (!file.baseFile.exists()) return null
        return runCatching { json.decodeFromString<StoredAccount>(vault.decrypt(file.readFully()).decodeToString()) }.getOrNull()
    }

    @Synchronized fun write(account: StoredAccount) {
        val bytes = vault.encrypt(json.encodeToString(account).encodeToByteArray())
        val out = file.startWrite()
        try { out.write(bytes); file.finishWrite(out) } catch (e: Exception) { file.failWrite(out); throw e }
    }

    @Synchronized fun clear() { file.delete() }
}
