package play.ott.nativeapp.ui

import play.ott.nativeapp.core.MediaEntry
import play.ott.nativeapp.core.Programme
import play.ott.nativeapp.core.SourceConfig
import play.ott.nativeapp.data.TrackPreference

/** A presentation snapshot. Network, persistence and playback ownership stay outside Compose. */
data class AppUiState(
    val sources: List<SourceConfig> = emptyList(),
    val selectedSourceId: String? = null,
    val entries: List<MediaEntry> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val epgEntry: MediaEntry? = null,
    val programmes: List<Programme> = emptyList(),
    val seriesEntry: MediaEntry? = null,
    val episodes: List<MediaEntry> = emptyList(),
    val playingEntry: MediaEntry? = null,
    val isBusy: Boolean = false,
    val loadingMessage: String = "",
    val error: String? = null,
    val notice: String? = null,
    val backgroundPlayback: Boolean = true,
    val localScanning: Boolean = false,
    val account: AccountUi = AccountUi(),
)

enum class AccountError { BAD_CREDENTIALS, NO_PACKAGE, NETWORK, CODE_INVALID, CODE_EXPIRED, SERVER, MISSING_FIELDS, SCANNER_UNAVAILABLE }

data class AccountPackageUi(val name: String, val expiresAt: String)

/** TELEVIZIA.STORE-ის ანგარიშის მდგომარეობა. პაროლი აქ არასდროს ინახება. */
data class AccountUi(
    /** შენახული შესვლა წაკითხულია (სანამ false, აპი საწყის ეკრანს აჩვენებს) */
    val loaded: Boolean = false,
    val signedIn: Boolean = false,
    val name: String = "",
    /** "package" | "trial" */
    val kind: String = "",
    val packages: List<AccountPackageUi> = emptyList(),
    val trialExpiresAt: String? = null,
    val expired: Boolean = false,
    val busy: Boolean = false,
    val error: AccountError? = null,
    /** TV-ზე ნაჩვენები კოდი და მისი QR მისამართი */
    val pairCode: String? = null,
    val pairUrl: String? = null,
)

sealed interface AppAction {
    data class SelectSource(val sourceId: String) : AppAction
    data class SaveSource(val source: SourceConfig) : AppAction
    data class DeleteSource(val sourceId: String) : AppAction
    data object Refresh : AppAction
    data class ToggleFavorite(val entry: MediaEntry) : AppAction
    data class Play(val entry: MediaEntry) : AppAction
    data class OpenEpg(val entry: MediaEntry) : AppAction
    data class PlayProgramme(val entry: MediaEntry, val programme: Programme) : AppAction
    data class OpenSeries(val entry: MediaEntry) : AppAction
    data object CloseEpg : AppAction
    data object CloseSeries : AppAction
    data object DismissError : AppAction
    data object DismissNotice : AppAction
    data object StopPlayback : AppAction
    data object ImportPlaylist : AppAction
    data object ImportLocalFolder : AppAction
    data object ImportLocalFiles : AppAction
    data object CancelLocalScan : AppAction
    data object PlayLocalShuffle : AppAction
    data object ExportSettings : AppAction
    data object ImportSettings : AppAction
    data object AddDemo : AppAction
    data class SetBackgroundPlayback(val enabled: Boolean) : AppAction
    data class SetTrackPreference(val audio: Boolean, val preference: TrackPreference) : AppAction
    data class Login(val email: String, val password: String) : AppAction
    /** TV: აჩვენებს QR-ს და ელოდება დადასტურებას ტელეფონიდან */
    data object StartPairing : AppAction
    data object StopPairing : AppAction
    /** ტელეფონი: კაბინეტის QR-დან ან ხელით შეყვანილი კოდი */
    data class PairWithCode(val code: String) : AppAction
    data object ScanQr : AppAction
    data object Logout : AppAction
    data object RefreshAccount : AppAction
    data object DismissAccountError : AppAction
    data class OpenSite(val page: String) : AppAction
}
