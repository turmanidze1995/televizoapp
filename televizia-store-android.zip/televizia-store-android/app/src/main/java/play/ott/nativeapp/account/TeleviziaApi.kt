package play.ott.nativeapp.account

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import play.ott.nativeapp.AppTransportPolicy
import java.io.IOException
import java.util.concurrent.TimeUnit

/** საიტის მისამართები. აპი მუშაობს მხოლოდ https-ით. */
object TeleviziaSite {
    const val BASE = "https://televizia.store"
    const val API = "$BASE/api/app.php"
    const val SOURCE_ID = "televizia-store"
    const val SOURCE_NAME = "TELEVIZIA.STORE"
    const val PAIR_TTL_SECONDS = 600

    fun pairPage(code: String) = "$BASE/public/pair.php?code=$code"
    fun page(path: String) = "$BASE/public/$path"
    /** კაბინეტის QR-ში ჩაწერილი ტექსტი: televizia://pair?code=XXXXXXXXXXXX */
    fun codeFrom(text: String): String? {
        val t = text.trim()
        val raw = when {
            t.startsWith("televizia://", ignoreCase = true) -> t.substringAfter("code=", "")
            t.startsWith("http", ignoreCase = true) && t.contains("code=") -> t.substringAfter("code=", "")
            else -> t
        }.substringBefore('&')
        val code = raw.filter { it.isLetterOrDigit() }.uppercase()
        return code.takeIf { it.length in 8..24 && it.all { c -> c in '0'..'9' || c in 'A'..'F' } }
    }
}

@Serializable
data class PackageInfo(val name: String = "", @SerialName("expires_at") val expiresAt: String = "")

@Serializable
data class TrialInfo(@SerialName("expires_at") val expiresAt: String = "")

/** საიტის პასუხი: token / playlist_url / პაკეტები / 24-საათიანი ტესტი */
@Serializable
data class SiteSession(
    val ok: Boolean = false,
    val token: String = "",
    val kind: String = "",
    val name: String = "",
    @SerialName("playlist_url") val playlistUrl: String = "",
    val packages: List<PackageInfo> = emptyList(),
    val trial: TrialInfo? = null,
    val error: String? = null,
) {
    override fun toString(): String = "SiteSession(kind=$kind)"   // ტოკენი ლოგებში არ ხვდება
}

@Serializable
private data class PairStartWire(val ok: Boolean = false, val code: String = "", @SerialName("expires_in") val expiresIn: Int = TeleviziaSite.PAIR_TTL_SECONDS)

data class PairStart(val code: String, val expiresIn: Int)

sealed interface ApiResult {
    data class Success(val session: SiteSession) : ApiResult
    /** TV-ს კოდი ჯერ არ დადასტურებულა */
    data object Pending : ApiResult
    data class Failure(val kind: Kind) : ApiResult
    enum class Kind { BAD_CREDENTIALS, NO_PACKAGE, INVALID_TOKEN, INVALID_CODE, EXPIRED, NETWORK, SERVER }
}

class TeleviziaApi(client: OkHttpClient? = null) {
    private val http = client ?: AppTransportPolicy.current.secure(
        OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    )
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

    suspend fun login(email: String, password: String): ApiResult = call(
        Request.Builder().url("${TeleviziaSite.API}?action=login")
            .post(FormBody.Builder().add("email", email.trim()).add("password", password).build()).build()
    )

    suspend fun refresh(token: String): ApiResult = call(get("refresh", "token" to token))

    suspend fun pairCheck(code: String): ApiResult = call(get("pair_check", "code" to code))

    suspend fun pairStart(): PairStart? = withContext(Dispatchers.IO) {
        try {
            http.newCall(get("pair_start")).execute().use { r ->
                val body = r.body.string()
                if (!r.isSuccessful) return@use null
                val wire = json.decodeFromString<PairStartWire>(body)
                if (wire.ok && wire.code.isNotBlank()) PairStart(wire.code, wire.expiresIn) else null
            }
        } catch (_: IOException) { null } catch (_: IllegalArgumentException) { null }
    }

    private fun get(action: String, vararg query: Pair<String, String>): Request {
        val url = TeleviziaSite.API.toHttpUrl().newBuilder().addQueryParameter("action", action)
            .apply { query.forEach { addQueryParameter(it.first, it.second) } }.build()
        return Request.Builder().url(url).get().build()
    }

    private suspend fun call(request: Request): ApiResult = withContext(Dispatchers.IO) {
        try {
            http.newCall(request).execute().use { r ->
                val body = r.body.string()
                val parsed = runCatching { json.decodeFromString<SiteSession>(body) }.getOrNull()
                val error = parsed?.error
                when {
                    r.code == 202 -> ApiResult.Pending
                    r.isSuccessful && parsed != null && parsed.ok && parsed.playlistUrl.startsWith("https://") ->
                        ApiResult.Success(parsed)
                    error == "bad_credentials" -> ApiResult.Failure(ApiResult.Kind.BAD_CREDENTIALS)
                    error == "no_active_package" || error == "no_token" -> ApiResult.Failure(ApiResult.Kind.NO_PACKAGE)
                    error == "invalid_token" -> ApiResult.Failure(ApiResult.Kind.INVALID_TOKEN)
                    error == "invalid_code" -> ApiResult.Failure(ApiResult.Kind.INVALID_CODE)
                    error == "expired" || error == "used" -> ApiResult.Failure(ApiResult.Kind.EXPIRED)
                    else -> ApiResult.Failure(ApiResult.Kind.SERVER)
                }
            }
        } catch (_: IOException) {
            ApiResult.Failure(ApiResult.Kind.NETWORK)
        }
    }
}
