package play.ott.nativeapp.ui

/** TELEVIZIA.STORE-ის ბიბლიოთეკის UI ტესტები იწყება უკვე შესული ანგარიშით (ლოგინის ეკრანი ცალკეა). */
internal val SIGNED_IN = AccountUi(loaded = true, signedIn = true)
