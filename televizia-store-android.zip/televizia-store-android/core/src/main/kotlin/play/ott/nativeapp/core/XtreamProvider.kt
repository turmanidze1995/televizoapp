package play.ott.nativeapp.core

import play.ott.core.XtreamAddresses
import play.ott.core.XtreamCatalogs
import play.ott.core.XtreamFailure
import play.ott.core.XtreamFormat
import play.ott.core.XtreamItem
import play.ott.core.ProviderValue
import play.ott.core.XtreamSeriesParent
import play.ott.core.XtreamLoad
import play.ott.core.XtreamSource
import okhttp3.HttpUrl

/** HTTP, URL codec and native model adapter for the common Xtream session. */
internal class XtreamProvider(private val http: ProviderHttp) {
    suspend fun load(config: SourceConfig): Catalog = translateFailure {
        val addresses = addresses(config)
        val load = XtreamLoad(source(config), addresses, { resolveHttp(config.url, it) }, { stableId(*it.toTypedArray()) })
        val session = load.session
        while (true) {
            val request = session.request ?: break
            try { session.accept(parseProviderJson(http.get(addresses.api(request), config.headers).text()).toProviderValue()) }
            catch (error: ProviderException) { if (!session.reject(error.statusCode)) throw error }
        }
        val normalized = load.catalog()
        val entries = normalized.entries.map { item(it, config, session.timezone) }
        val epg = if (config.epgUrl.isNotBlank()) httpUrl(config.epgUrl).toString() else addresses.epg()
        val messages = session.notices.map { notice -> CoreMessage(
            if (notice.code == "GROUPS") CoreMessageKey.XTREAM_GROUPS_UNAVAILABLE else CoreMessageKey.XTREAM_SECTION_UNAVAILABLE,
            listOf(notice.kind, notice.status.toString())) }
        Catalog(entries, listOf(epg), messages.map { it.english() }, messages)
    }

    suspend fun episodes(config: SourceConfig, series: MediaEntry): List<MediaEntry> = translateFailure {
        val id = series.providerId
        val addresses = addresses(config)
        val request = XtreamCatalogs.seriesRequest(ProviderValue.text(id), "", XtreamFormat.ANDROID)
        val data = parseProviderJson(http.get(addresses.api(request), config.headers).text()).toProviderValue()
        XtreamCatalogs.episodes(data, XtreamFormat.ANDROID, source(config), addresses,
            XtreamSeriesParent(id, series.name, series.logo), { resolveHttp(config.url, it) }, { it },
            { stableId(*it.toTypedArray()) }).entries.map { item(it, config, "UTC") }
    }

    private fun source(config: SourceConfig) = XtreamSource(config.id, config.username, config.password)
    private fun addresses(config: SourceConfig): XtreamAddresses {
        val input = httpUrl(config.url)
        val base = input.newBuilder().encodedPath("/").query(null).fragment(null).apply {
            XtreamAddresses.nativeBaseSegments(input.pathSegments).forEach { addPathSegment(it) }
        }.build()
        return XtreamAddresses(source(config), { path, query -> base.newBuilder().apply {
            path.forEach { addPathSegment(it) }; query.forEach { (key, value) -> addQueryParameter(key, value) }
        }.build().toString() }, { value ->
            HttpUrl.Builder().scheme("https").host("template.invalid").addPathSegment(value).build().encodedPath.removePrefix("/")
        })
    }
    private fun item(entry: XtreamItem, config: SourceConfig, zone: String): MediaEntry {
        val kind = when (entry.kind) { "vod" -> MediaKind.MOVIE; "series" -> MediaKind.SERIES; "episode" -> MediaKind.EPISODE; else -> MediaKind.LIVE }
        return MediaEntry(entry.id, config.id, entry.name, entry.url, kind, group = entry.group, logo = entry.logo,
            epgId = entry.epgId, headers = config.headers,
            catchup = entry.archiveDays?.let { Catchup("xtream", entry.archiveSource, it, zone) },
            description = entry.description, season = entry.season.toIntOrNull(), episode = entry.episode?.toInt(),
            providerId = entry.providerId, headerOrigins = headerOrigins(config.headers, config.url),
            nameMessage = if (entry.generatedName.isEmpty()) null else CoreMessage(
                if (kind == MediaKind.EPISODE) CoreMessageKey.EPISODE else CoreMessageKey.UNTITLED, listOf(entry.generatedName)),
            groupMessage = if (entry.generatedGroup) CoreMessage(CoreMessageKey.OTHER_GROUP) else null)
    }
    private suspend fun <T> translateFailure(block: suspend () -> T): T = try { block() } catch (failure: XtreamFailure) {
        throw ProviderException(when (failure.code) {
            "ACCOUNT_FORMAT" -> "Invalid Xtream account response"
            "AUTH" -> "Xtream rejected the username or password"
            "INACTIVE" -> "Xtream account is not active"
            "CATEGORY_FORMAT" -> "Xtream categories has an unexpected format"
            "CATALOG_FORMAT" -> "Xtream catalogue has an unexpected format"
            "CATALOG_LIMIT" -> "Xtream catalogue contains more than 100,000 entries"
            "SERIES_ID" -> "Series identifier is missing"
            "SERIES_FORMAT" -> "Invalid Xtream series response"
            "EPISODES_FORMAT" -> "Xtream returned no episode list"
            "EPISODES_LIMIT" -> "Series contains too many episodes"
            else -> "Provider returned an unsupported response"
        })
    }
}
